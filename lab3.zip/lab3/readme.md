"Dodano nową sekcję nawigacji i opis celów w pliku main.html."
"Wykorzystano git commit --amend do poprawy commita z zapomnianym plikiem."
# Projekt Lab Git
## Lista zadań
- [x] Konfiguracja
- [x] Edycja HTML
- [ ] Nauka Rebase

## Linki
[Strona PG](https://pg.edu.pl)